Effect.Game.xl.nl({
	"Code": 0,
	"Path": "/text/game.xml",
	"Data": {
		"KonamiCode": {
			"Key": [
				"move_up",
				"move_up",
				"move_down",
				"move_down",
				"move_left",
				"move_right",
				"move_left",
				"move_right",
				"button_1",
				"button_2"
			]
		},
		"BonusStack": {
			"Amount": [
				100,
				200,
				400,
				500,
				800,
				1000,
				2000,
				5000
			]
		}
	},
	"Description": "Success"
});
